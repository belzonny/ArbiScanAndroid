# Optional Bybit P2P quote bridge

This small Node.js 20+ service signs Bybit P2P `POST /v5/p2p/item/online` requests server-side, so the exchange API secret is not embedded in the Android app. Bybit restricts this P2P API to eligible advertiser accounts; ordinary users may not be able to use it.

## Required environment variables
- `BYBIT_API_KEY`: API key for an eligible Bybit P2P advertiser account; enable only the permissions needed for the P2P ads query.
- `BYBIT_API_SECRET`: corresponding secret.
- `BRIDGE_TOKEN`: long random secret used between your app and bridge.
- `PORT`: optional, defaults to 8080.

Never commit real credentials to a repository. Configure them as private environment variables in your hosting provider. Use HTTPS in production. Do not disable certificate checks. Restrict usage to your own app and rotate the bridge token if exposed.

## Run locally
```sh
npm start
```
Set the app's Bybit P2P bridge URL to the public HTTPS base URL (no trailing slash), and Bridge access token to the same value as `BRIDGE_TOKEN`. The app requests `/p2p/bybit/quotes?asset=USDT&fiat=TZS`.

The server returns the lowest current sell-ad price as `buyPrice` and highest current buy-ad price as `sellPrice`, plus offer counts and fetch time. These are advertised quotes, not guaranteed fills. The service does not create ads, place orders, or handle funds.
