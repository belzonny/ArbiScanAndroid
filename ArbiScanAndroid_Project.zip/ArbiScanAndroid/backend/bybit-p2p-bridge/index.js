'use strict';

const http = require('node:http');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.BYBIT_API_KEY || '';
const API_SECRET = process.env.BYBIT_API_SECRET || '';
const BRIDGE_TOKEN = process.env.BRIDGE_TOKEN || '';
const RECV_WINDOW = '5000';

function json(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
  });
  res.end(body);
}

function constantTimeMatch(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

async function bybitAds(currencyId, side) {
  const timestamp = Date.now().toString();
  const payload = { tokenId: 'USDT', currencyId, side, page: '1', size: '50' };
  const body = JSON.stringify(payload);
  const signText = timestamp + API_KEY + RECV_WINDOW + body;
  const signature = crypto.createHmac('sha256', API_SECRET).update(signText).digest('hex');
  const response = await fetch('https://api.bybit.com/v5/p2p/item/online', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-BAPI-API-KEY': API_KEY,
      'X-BAPI-SIGN': signature,
      'X-BAPI-TIMESTAMP': timestamp,
      'X-BAPI-RECV-WINDOW': RECV_WINDOW
    },
    body,
    signal: AbortSignal.timeout(12000)
  });
  const data = await response.json();
  const code = data.retCode ?? data.ret_code;
  if (!response.ok || Number(code) !== 0) {
    throw new Error(`Bybit response ${response.status}/${code}: ${String(data.retMsg || data.ret_msg || 'API error').slice(0, 120)}`);
  }
  const result = data.result || {};
  return Array.isArray(result.items) ? result.items : [];
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') return json(res, 200, { ok: true, service: 'ArbiScan Bybit P2P bridge' });
  if (req.method !== 'GET' || url.pathname !== '/p2p/bybit/quotes') return json(res, 404, { error: 'Not found' });

  if (!API_KEY || !API_SECRET || !BRIDGE_TOKEN) {
    return json(res, 503, { error: 'Set BYBIT_API_KEY, BYBIT_API_SECRET, and BRIDGE_TOKEN on the server.' });
  }
  if (!constantTimeMatch(req.headers['x-arbiscan-token'], BRIDGE_TOKEN)) {
    return json(res, 401, { error: 'Invalid bridge token.' });
  }

  const asset = url.searchParams.get('asset') || 'USDT';
  const fiat = (url.searchParams.get('fiat') || 'TZS').toUpperCase();
  if (asset !== 'USDT' || !/^[A-Z]{3,5}$/.test(fiat)) return json(res, 400, { error: 'Unsupported asset or invalid fiat code.' });

  try {
    // Bybit side=1 are sell ads: the best user-buy price is the lowest ask.
    // Bybit side=0 are buy ads: the best user-sell price is the highest bid.
    const [sellAds, buyAds] = await Promise.all([bybitAds(fiat, '1'), bybitAds(fiat, '0')]);
    const price = item => Number(item.price || 0);
    const validSell = sellAds.filter(x => Number(x.isOnline !== false) && price(x) > 0);
    const validBuy = buyAds.filter(x => Number(x.isOnline !== false) && price(x) > 0);
    const lowestAsk = validSell.reduce((best, x) => !best || price(x) < price(best) ? x : best, null);
    const highestBid = validBuy.reduce((best, x) => !best || price(x) > price(best) ? x : best, null);
    if (!lowestAsk || !highestBid) return json(res, 200, { error: `No usable public ads for USDT/${fiat}.` });
    return json(res, 200, {
      buyPrice: price(lowestAsk),
      sellPrice: price(highestBid),
      buyAds: validSell.length,
      sellAds: validBuy.length,
      fiat,
      asset: 'USDT',
      fetchedAt: new Date().toISOString()
    });
  } catch (e) {
    return json(res, 502, { error: String(e.message || e).slice(0, 200) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`ArbiScan Bybit P2P bridge listening on ${PORT}`);
});
