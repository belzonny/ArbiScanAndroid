# ArbiScan Android — source build 0.1.0

A native Android/Kotlin + Jetpack Compose starting build for a mobile arbitrage scanner.

## Included
- Dark mobile UI with Scanner, P2P, Exchanges, and Settings tabs.
- Live public spot bid/ask feeds from Binance Spot and Bybit Spot.
- Cross-exchange spread estimation using buy ask versus sell bid.
- Configurable minimum net threshold, default **1.00%** (the slider cannot be set below 1%).
- Configurable trading fee per side and extra-cost reserve.
- Scans the top 100–300 common USDT pairs available from both feeds; does not create sample prices.
- Shows opportunities only when the estimate meets the configured net threshold.
- Exchange feed status and error messages.
- Binance P2P public-ad query attempt for the fiat code set in Settings.
- Bybit P2P card plus optional secure backend-bridge interface.
- Android notification when a qualifying spot opportunity is found (permission required).
- 30-second auto-refresh while the app is open.

## Important limitations (read before using real money)
1. **A 1% filter is not a profit guarantee.** No current qualifying trades means the app intentionally shows zero results.
2. Spot estimates use best bid/ask and configured fees. The "extra cost reserve" is an allowance you set—not a live network/withdrawal quote. Market impact, order execution, tax, conversion costs, and rebalancing costs may differ.
3. Cross-exchange arbitrage generally assumes you already have funds on both exchanges. The app does not place trades or hold credentials.
4. Binance's P2P ad search endpoint is an undocumented/public web endpoint and may change, rate-limit, or block requests. If it is blocked, the app reports it as unavailable; it will not substitute fake prices.
5. Bybit's official P2P API requires eligible P2P advertiser access and authenticated requests. Do **not** place API secrets in the Android app. Use a secure HTTPS server/bridge that keeps credentials server-side.
6. The app auto-refreshes only while the app is open. It is not yet a persistent background trading service.
7. The Exchanges tab lists future integration targets. Only Binance and Bybit Spot have live quote connectors in this first build.

## Build with Android Studio
- Use a recent Android Studio version with JDK 17.
- Open this project folder (`ArbiScanAndroid`) in Android Studio.
- Let Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Install the debug APK on your Android phone.
- Internet access is required for live data; permit notification access if you want Android alerts.

Gradle configuration uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, compile SDK 35, and minimum SDK 26.

## Optional Bybit P2P bridge contract
Set the bridge base URL in Settings. The app requests:

`GET https://YOUR-SERVER/p2p/bybit/quotes?asset=USDT&fiat=TZS`

Expected JSON:
```json
{
  "buyPrice": 2500.0,
  "sellPrice": 2540.0,
  "buyAds": 12,
  "sellAds": 8
}
```
All values must be real current offer-derived quotes from an authorized integration. `buyPrice` should be the best executable advertiser offer for a user buying USDT; `sellPrice` should be the best executable offer for a user selling USDT. The bridge must validate ad sizes/payment methods and should keep API keys/secrets server-side. Do not deploy an unauthenticated endpoint that leaks private advertiser account data.

## Project status
This is a source project, not a precompiled APK. No live-trading credentials or order-execution functions are included.

## Optional Bybit P2P bridge included
The `backend/bybit-p2p-bridge/` folder contains a Node.js 20+ quote bridge. It keeps Bybit signing keys on a server and requires an eligible advertiser account plus a bridge token. It must be deployed by the user before the app can show live Bybit P2P quotes; Binance P2P does not use this bridge. See that folder's README.
