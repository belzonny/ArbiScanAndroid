package com.arbiscan.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.roundToInt

private val Bg = Color(0xFF07090D)
private val Panel = Color(0xFF10141B)
private val Panel2 = Color(0xFF161C26)
private val Green = Color(0xFF23D98B)
private val Muted = Color(0xFF8993A3)
private val Line = Color(0xFF242C38)
private val Red = Color(0xFFFF5C75)
private val Blue = Color(0xFF8994FF)
private val White = Color(0xFFF3F6FB)

private const val CHANNEL_ID = "arbiscan_opportunities"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 402)
        }
        setContent { ArbiScanApp() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Arbitrage opportunities", NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Alerts when a live opportunity passes your net-profit threshold." }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}

private enum class Page { SCANNER, P2P, EXCHANGES, SETTINGS }

private data class Quote(
    val symbol: String,
    val bid: Double,
    val bidQty: Double,
    val ask: Double,
    val askQty: Double,
    val turnover: Double = 0.0
)

private data class Opportunity(
    val symbol: String,
    val buyExchange: String,
    val sellExchange: String,
    val buyPrice: Double,
    val sellPrice: Double,
    val grossPct: Double,
    val netPct: Double,
    val estimatedUsdCapacity: Double
)

private data class ScanReport(
    val opportunities: List<Opportunity> = emptyList(),
    val commonPairs: Int = 0,
    val binanceStatus: String = "Not scanned",
    val bybitStatus: String = "Not scanned",
    val message: String = "Tap Scan now to load live order-book prices."
)

private data class P2PReport(
    val platform: String,
    val status: String,
    val buyPrice: Double? = null,
    val sellPrice: Double? = null,
    val netPct: Double? = null,
    val buyAds: Int = 0,
    val sellAds: Int = 0,
    val detail: String = "",
    val isLive: Boolean = false
)

@Composable
private fun ArbiScanApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("arbiscan_settings", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf(Page.SCANNER) }
    var minimumNet by remember { mutableFloatStateOf(prefs.getFloat("minimumNet", 1.0f).coerceAtLeast(1.0f)) }
    var feePerSide by remember { mutableFloatStateOf(prefs.getFloat("feePerSide", 0.10f)) }
    var extraReserve by remember { mutableFloatStateOf(prefs.getFloat("extraReserve", 0.25f)) }
    var fiat by remember { mutableStateOf(prefs.getString("fiat", "TZS") ?: "TZS") }
    var bridgeUrl by remember { mutableStateOf(prefs.getString("bridgeUrl", "") ?: "") }
    var bridgeToken by remember { mutableStateOf(prefs.getString("bridgeToken", "") ?: "") }
    var assetLimit by remember { mutableFloatStateOf(prefs.getFloat("assetLimit", 150f).coerceIn(100f, 300f)) }
    var autoScanning by remember { mutableStateOf(false) }
    var refreshing by remember { mutableStateOf(false) }
    var lastUpdated by remember { mutableStateOf("Not yet updated") }
    var scanReport by remember { mutableStateOf(ScanReport()) }
    var p2pReports by remember {
        mutableStateOf(
            listOf(
                P2PReport("Binance P2P", "Not checked", detail = "Live public-ad query has not run."),
                P2PReport("Bybit P2P", "Setup required", detail = "An eligible advertiser account and a secure API bridge are required.")
            )
        )
    }
    val scope = rememberCoroutineScope()

    suspend fun refreshAll() {
        if (refreshing) return
        refreshing = true
        try {
            val outcome = withContext(Dispatchers.IO) {
                coroutineScope {
                    val scan = async { scanSpotMarkets(feePerSide.toDouble(), extraReserve.toDouble(), minimumNet.toDouble(), assetLimit.toInt()) }
                    val binanceP2P = async { scanBinanceP2P(fiat.trim().uppercase(Locale.US), minimumNet.toDouble(), extraReserve.toDouble()) }
                    val bybitP2P = async { scanBybitP2P(bridgeUrl.trim(), bridgeToken.trim(), fiat.trim().uppercase(Locale.US), minimumNet.toDouble(), extraReserve.toDouble()) }
                    Triple(scan.await(), binanceP2P.await(), bybitP2P.await())
                }
            }
            scanReport = outcome.first
            p2pReports = listOf(outcome.second, outcome.third)
            lastUpdated = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())
            maybeNotifyOpportunity(context, prefs, scanReport.opportunities.firstOrNull())
        } catch (e: Exception) {
            scanReport = scanReport.copy(message = "Refresh failed: ${safeMessage(e)}")
        } finally {
            refreshing = false
        }
    }

    LaunchedEffect(autoScanning, minimumNet, feePerSide, extraReserve, fiat, bridgeUrl, assetLimit) {
        if (autoScanning) {
            while (isActive) {
                refreshAll()
                delay(30_000)
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green, secondary = Blue, background = Bg, surface = Panel,
            onBackground = White, onSurface = White, error = Red
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B0E13), contentColor = White) {
                    NavigationBarItem(
                        selected = page == Page.SCANNER, onClick = { page = Page.SCANNER },
                        icon = { Icon(Icons.Default.ShowChart, contentDescription = null) },
                        label = { Text("Scanner", fontSize = 10.sp) },
                        colors = navColors()
                    )
                    NavigationBarItem(
                        selected = page == Page.P2P, onClick = { page = Page.P2P },
                        icon = { Icon(Icons.Default.CompareArrows, contentDescription = null) },
                        label = { Text("P2P", fontSize = 10.sp) },
                        colors = navColors()
                    )
                    NavigationBarItem(
                        selected = page == Page.EXCHANGES, onClick = { page = Page.EXCHANGES },
                        icon = { Icon(Icons.Default.AccountBalance, contentDescription = null) },
                        label = { Text("Exchanges", fontSize = 10.sp) },
                        colors = navColors()
                    )
                    NavigationBarItem(
                        selected = page == Page.SETTINGS, onClick = { page = Page.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings", fontSize = 10.sp) },
                        colors = navColors()
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).background(Bg)
            ) {
                Header(isScanning = autoScanning, refreshing = refreshing)
                when (page) {
                    Page.SCANNER -> ScannerPage(
                        report = scanReport,
                        threshold = minimumNet,
                        lastUpdated = lastUpdated,
                        refreshing = refreshing,
                        autoScanning = autoScanning,
                        onRefresh = { scope.launch { refreshAll() } },
                        onToggleAuto = { autoScanning = !autoScanning }
                    )
                    Page.P2P -> P2PPage(
                        reports = p2pReports, fiat = fiat, threshold = minimumNet,
                        refreshing = refreshing,
                        onRefresh = { scope.launch { refreshAll() } },
                        onOpen = { url -> openWeb(context, url) }
                    )
                    Page.EXCHANGES -> ExchangesPage(
                        binanceStatus = scanReport.binanceStatus,
                        bybitStatus = scanReport.bybitStatus
                    )
                    Page.SETTINGS -> SettingsPage(
                        minimumNet = minimumNet,
                        feePerSide = feePerSide,
                        extraReserve = extraReserve,
                        fiat = fiat,
                        bridgeUrl = bridgeUrl,
                        bridgeToken = bridgeToken,
                        assetLimit = assetLimit,
                        onMinimumNet = {
                            minimumNet = it.coerceAtLeast(1f)
                            prefs.edit().putFloat("minimumNet", minimumNet).apply()
                        },
                        onFee = {
                            feePerSide = it
                            prefs.edit().putFloat("feePerSide", feePerSide).apply()
                        },
                        onReserve = {
                            extraReserve = it
                            prefs.edit().putFloat("extraReserve", extraReserve).apply()
                        },
                        onFiat = {
                            fiat = it.uppercase(Locale.US).filter { c -> c.isLetter() }.take(5)
                            prefs.edit().putString("fiat", fiat).apply()
                        },
                        onBridgeUrl = {
                            bridgeUrl = it.trim()
                            prefs.edit().putString("bridgeUrl", bridgeUrl).apply()
                        },
                        onBridgeToken = {
                            bridgeToken = it.trim()
                            prefs.edit().putString("bridgeToken", bridgeToken).apply()
                        },
                        onAssetLimit = {
                            assetLimit = it
                            prefs.edit().putFloat("assetLimit", assetLimit).apply()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Green,
    selectedTextColor = Green,
    indicatorColor = Color(0xFF153326),
    unselectedIconColor = Muted,
    unselectedTextColor = Muted
)

@Composable
private fun Header(isScanning: Boolean, refreshing: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier.size(35.dp).background(Color(0xFF153326), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Bolt, contentDescription = null, tint = Green) }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Arbi", color = White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("Scan", color = Green, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                }
                Text("ARBITRAGE MONITOR", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
        }
        val label = when { refreshing -> "● UPDATING"; isScanning -> "● SCANNING"; else -> "● READY" }
        Surface(color = if (isScanning || refreshing) Color(0xFF143323) else Panel2, shape = RoundedCornerShape(30.dp)) {
            Text(label, color = if (isScanning || refreshing) Green else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
        }
    }
}

@Composable
private fun ScannerPage(
    report: ScanReport, threshold: Float, lastUpdated: String, refreshing: Boolean,
    autoScanning: Boolean, onRefresh: () -> Unit, onToggleAuto: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Line)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("LIVE ARBITRAGE SCANNER", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${report.opportunities.size}", color = White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                        Text("qualifying opportunities", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 7.dp))
                    }
                    Text("Showing only estimated net profit ≥ ${pct(threshold.toDouble())}", color = Green, fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onRefresh, enabled = !refreshing, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF03120C))) {
                            Text(if (refreshing) "Updating…" else "↻  Scan now", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(onClick = onToggleAuto, modifier = Modifier.weight(1f), shape = RoundedCornerShape(13.dp), border = BorderStroke(1.dp, if (autoScanning) Green else Line)) {
                            Text(if (autoScanning) "■ Stop auto" else "▶ Auto · 30s", color = if (autoScanning) Green else White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text("Last update: $lastUpdated", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile("COINS COMPARED", report.commonPairs.toString(), Modifier.weight(1f))
                StatTile("EXCHANGES LIVE", listOf(report.binanceStatus, report.bybitStatus).count { it.startsWith("ONLINE") }.toString() + "/2", Modifier.weight(1f))
                StatTile("MIN. NET", pct(threshold.toDouble()), Modifier.weight(1f))
            }
        }
        item {
            SectionTitle("🔥  Opportunities", "LIVE DATA")
        }
        if (report.opportunities.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Line)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("No qualifying opportunity yet", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(report.message, color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
                        Text("No sample prices are used. If a feed fails or net profit is below your threshold, no trade is shown.", color = Blue, fontSize = 11.sp, lineHeight = 16.sp)
                    }
                }
            }
        } else {
            items(report.opportunities, key = { "${it.symbol}-${it.buyExchange}-${it.sellExchange}" }) { opportunity ->
                OpportunityCard(opportunity)
            }
        }
        item {
            SectionTitle("Connection health", "2 SPOT FEEDS")
        }
        item { FeedStatusCard("Binance Spot", report.binanceStatus) }
        item { FeedStatusCard("Bybit Spot", report.bybitStatus) }
        item {
            Text(
                "Estimate only: uses top-of-book bid/ask, configured trading fees and your extra-cost reserve. It excludes market impact and may not include the exact withdrawal/network fee. Cross-exchange trading generally assumes funds are already available on both exchanges.",
                color = Muted, fontSize = 10.sp, lineHeight = 15.sp,
                modifier = Modifier.padding(top = 3.dp, bottom = 4.dp)
            )
        }
    }
}

@Composable
private fun OpportunityCard(o: Opportunity) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(39.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                        Text(o.symbol.removeSuffix("USDT").take(3), color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(o.symbol, color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Spot · cross-exchange", color = Muted, fontSize = 10.sp)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("+${pct(o.netPct)}", color = Green, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp)
                    Text("EST. NET", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PriceBox("BUY · ${o.buyExchange}", price(o.buyPrice), Red, Modifier.weight(1f))
                PriceBox("SELL · ${o.sellExchange}", price(o.sellPrice), Green, Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Gross spread  ${pct(o.grossPct)}", color = Muted, fontSize = 10.sp)
                Text("Top-book size ~ ${money(o.estimatedUsdCapacity)}", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun P2PPage(
    reports: List<P2PReport>, fiat: String, threshold: Float, refreshing: Boolean,
    onRefresh: () -> Unit, onOpen: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Line)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("P2P ARBITRAGE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Text("Compare peer-to-peer offers", color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
                    Text("Asset: USDT  ·  Fiat: $fiat  ·  Alert floor: ${pct(threshold.toDouble())} net", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(13.dp))
                    Button(onClick = onRefresh, enabled = !refreshing, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF03120C))) {
                        Text(if (refreshing) "Updating…" else "↻  Refresh P2P offers", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        items(reports, key = { it.platform }) { report ->
            P2PCard(report = report, fiat = fiat, threshold = threshold.toDouble(), onOpen = onOpen)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("P2P safety checklist", fontWeight = FontWeight.Bold, color = White, fontSize = 13.sp)
                    Text("Use only offers that match your payment method and trade size. Check seller completion rate, limits, and whether the quote is still available. Never release crypto based on screenshots or a payment notification alone.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun P2PCard(report: P2PReport, fiat: String, threshold: Double, onOpen: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, if (report.netPct != null && report.netPct >= threshold) Color(0xFF24694A) else Line)
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text(report.platform, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("USDT / fiat ads", color = Muted, fontSize = 10.sp)
                }
                StatusChip(
                    label = when {
                        report.netPct != null && report.netPct >= threshold -> "≥ TARGET"
                        report.isLive -> "LIVE"
                        else -> report.status.uppercase(Locale.US).take(18)
                    },
                    good = report.netPct != null && report.netPct >= threshold
                )
            }
            if (report.buyPrice != null && report.sellPrice != null && report.netPct != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PriceBox("LOWEST BUY OFFER", "$fiat ${moneyLocal(report.buyPrice)}", Red, Modifier.weight(1f))
                    PriceBox("HIGHEST SELL OFFER", "$fiat ${moneyLocal(report.sellPrice)}", Green, Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("ESTIMATED NET", color = Muted, fontSize = 9.sp)
                        Text("${if (report.netPct >= 0) "+" else ""}${pct(report.netPct)}", color = if (report.netPct >= threshold) Green else Muted, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("ADS CHECKED", color = Muted, fontSize = 9.sp)
                        Text("${report.buyAds} buy · ${report.sellAds} sell", color = White, fontSize = 11.sp)
                    }
                }
            }
            Text(report.detail, color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            val url = if (report.platform.startsWith("Binance")) "https://p2p.binance.com/" else "https://www.bybit.com/en/fiat/trade/otc/buy/USDT"
            OutlinedButton(onClick = { onOpen(url) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Line)) {
                Text("Open ${report.platform}", color = White, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ExchangesPage(binanceStatus: String, bybitStatus: String) {
    val names = listOf(
        "Binance" to binanceStatus,
        "Bybit" to bybitStatus,
        "OKX" to "NOT CONNECTED · planned",
        "Coinbase" to "NOT CONNECTED · planned",
        "Kraken" to "NOT CONNECTED · planned",
        "KuCoin" to "NOT CONNECTED · planned",
        "Bitget" to "NOT CONNECTED · planned",
        "Gate.io" to "NOT CONNECTED · planned",
        "MEXC" to "NOT CONNECTED · planned",
        "Crypto.com" to "NOT CONNECTED · planned",
        "HTX" to "NOT CONNECTED · planned",
        "LBank" to "NOT CONNECTED · planned"
    )
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        item {
            SectionTitle("Exchange connections", "12 LISTED")
            Text("The first build uses live public spot data from Binance and Bybit. Other exchanges are listed for the next integration phase and are not represented as live feeds yet.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        items(names, key = { it.first }) { (name, status) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(35.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                        Text(name.take(1), color = if (status.startsWith("ONLINE")) Green else Blue, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(status, color = if (status.startsWith("ONLINE")) Green else Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsPage(
    minimumNet: Float, feePerSide: Float, extraReserve: Float, fiat: String, bridgeUrl: String, bridgeToken: String, assetLimit: Float,
    onMinimumNet: (Float) -> Unit, onFee: (Float) -> Unit, onReserve: (Float) -> Unit,
    onFiat: (String) -> Unit, onBridgeUrl: (String) -> Unit, onBridgeToken: (String) -> Unit, onAssetLimit: (Float) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SectionTitle("Scanner settings", "SAVED ON DEVICE") }
        item {
            SettingsCard(title = "Minimum estimated net profit", value = pct(minimumNet.toDouble()), description = "The scanner only lists opportunities at or above this threshold.") {
                Slider(value = minimumNet, onValueChange = { onMinimumNet((it * 4).roundToInt() / 4f) }, valueRange = 1f..5f, steps = 15, colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("1.0%", color = Muted, fontSize = 10.sp); Text("5.0%", color = Muted, fontSize = 10.sp)
                }
            }
        }
        item {
            SettingsCard(title = "Trading fee per side", value = pct(feePerSide.toDouble()), description = "Applied once at buy and once at sell. Replace with your account's actual fee tier.") {
                Slider(value = feePerSide, onValueChange = { onFee((it * 100).roundToInt() / 100f) }, valueRange = 0.05f..0.50f, steps = 8, colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
            }
        }
        item {
            SettingsCard(title = "Extra cost reserve", value = pct(extraReserve.toDouble()), description = "A configurable allowance for costs not included in the public ticker. It is not a live network-fee quote.") {
                Slider(value = extraReserve, onValueChange = { onReserve((it * 20).roundToInt() / 20f) }, valueRange = 0f..1f, steps = 19, colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
            }
        }
        item {
            SettingsCard(title = "P2P fiat currency", value = fiat, description = "The Binance P2P query uses this currency. Offer availability depends on the market.") {
                OutlinedTextField(value = fiat, onValueChange = onFiat, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Fiat code, e.g. TZS") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text), colors = fieldColors())
            }
        }
        item {
            SettingsCard(title = "Spot pairs to compare", value = assetLimit.toInt().toString(), description = "The app supports more than 100 matched USDT pairs when both exchange feeds provide them.") {
                Slider(value = assetLimit, onValueChange = { onAssetLimit((it / 50).roundToInt() * 50f) }, valueRange = 100f..300f, steps = 3, colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("100 pairs", color = Muted, fontSize = 10.sp); Text("300 pairs", color = Muted, fontSize = 10.sp)
                }
            }
        }
        item {
            SettingsCard(title = "Bybit P2P data bridge (optional)", value = if (bridgeUrl.isBlank()) "Not configured" else "Configured", description = "Bybit's official P2P ads API requires eligible advertiser access. Keep Bybit API secrets on your HTTPS server, not in this app.") {
                OutlinedTextField(value = bridgeUrl, onValueChange = onBridgeUrl, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("https://your-secure-server.example") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri), colors = fieldColors())
                OutlinedTextField(value = bridgeToken, onValueChange = onBridgeToken, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Bridge access token") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), colors = fieldColors())
                Text("Expected endpoint: GET /p2p/bybit/quotes?asset=USDT&fiat=TZS returning buyPrice, sellPrice, buyAds, sellAds. Bridge token must match BRIDGE_TOKEN on your server.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("No credentials required for the spot scanner", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("This version does not place trades. It uses public market data and sends an Android notification only when a scan identifies a qualifying opportunity. Auto-scan runs while the app remains open.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, value: String, description: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Text(value, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Text(description, color = Muted, fontSize = 10.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 5.dp, bottom = 6.dp))
            content()
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = White, unfocusedTextColor = White,
    focusedBorderColor = Green, unfocusedBorderColor = Line,
    focusedLabelColor = Green, unfocusedLabelColor = Muted,
    cursorColor = Green
)

@Composable
private fun FeedStatusCard(name: String, status: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).background(if (status.startsWith("ONLINE")) Green else Red, CircleShape))
            Column(Modifier.padding(start = 10.dp)) {
                Text(name, color = White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(status, color = if (status.startsWith("ONLINE")) Green else Muted, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, trailing: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(trailing, color = Blue, fontSize = 9.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Line)) {
        Column(Modifier.fillMaxWidth().padding(11.dp)) {
            Text(value, color = White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(label, color = Muted, fontSize = 8.sp, letterSpacing = .5.sp, maxLines = 2)
        }
    }
}

@Composable
private fun PriceBox(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel2, RoundedCornerShape(12.dp)).padding(10.dp)) {
        Text(label, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun StatusChip(label: String, good: Boolean) {
    Surface(color = if (good) Color(0xFF153326) else Panel2, shape = RoundedCornerShape(8.dp)) {
        Text(label, color = if (good) Green else Muted, fontWeight = FontWeight.Bold, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
    }
}

private suspend fun scanSpotMarkets(feePerSide: Double, reservePct: Double, minimumNet: Double, limit: Int): ScanReport {
    val (binanceResult, bybitResult) = coroutineScope {
        val b = async(Dispatchers.IO) { runCatching { fetchBinanceSpotQuotes() } }
        val y = async(Dispatchers.IO) { runCatching { fetchBybitSpotQuotes() } }
        b.await() to y.await()
    }
    val bMap = binanceResult.getOrNull()
    val yMap = bybitResult.getOrNull()
    val bStatus = if (bMap != null) "ONLINE · ${bMap.size} tickers" else "OFFLINE · ${safeMessage(binanceResult.exceptionOrNull())}"
    val yStatus = if (yMap != null) "ONLINE · ${yMap.size} tickers" else "OFFLINE · ${safeMessage(bybitResult.exceptionOrNull())}"
    if (bMap == null || yMap == null) {
        return ScanReport(
            commonPairs = 0, binanceStatus = bStatus, bybitStatus = yStatus,
            message = "A complete comparison needs both live feeds. Check your connection or try again later."
        )
    }

    val common = bMap.keys.intersect(yMap.keys)
        .filter { it.endsWith("USDT") && isPlainSpotAsset(it.removeSuffix("USDT")) }
        .sortedByDescending { yMap[it]?.turnover ?: 0.0 }
        .take(limit.coerceIn(100, 300))
    val results = ArrayList<Opportunity>()

    fun evaluate(symbol: String, buyName: String, buy: Quote, sellName: String, sell: Quote) {
        if (buy.ask <= 0.0 || sell.bid <= 0.0 || sell.bid <= buy.ask) return
        val gross = (sell.bid - buy.ask) / buy.ask * 100.0
        val net = gross - 2.0 * feePerSide - reservePct
        if (net + 1e-10 < minimumNet) return
        val usdAskCapacity = buy.askQty.coerceAtLeast(0.0) * buy.ask
        val usdBidCapacity = sell.bidQty.coerceAtLeast(0.0) * sell.bid
        results += Opportunity(
            symbol, buyName, sellName, buy.ask, sell.bid, gross, net,
            minOf(usdAskCapacity, usdBidCapacity)
        )
    }

    for (symbol in common) {
        val b = bMap[symbol] ?: continue
        val y = yMap[symbol] ?: continue
        evaluate(symbol, "Binance", b, "Bybit", y)
        evaluate(symbol, "Bybit", y, "Binance", b)
    }
    results.sortByDescending { it.netPct }
    val msg = if (results.isEmpty()) {
        "No live opportunity currently clears ${pct(minimumNet)} estimated net. That is a valid result—not an error or a reason to invent prices."
    } else {
        "Found ${results.size} live candidate(s) above the ${pct(minimumNet)} filter. Verify depth, fees, and executable prices before trading."
    }
    return ScanReport(results.take(50), common.size, bStatus, yStatus, msg)
}

private fun fetchBinanceSpotQuotes(): Map<String, Quote> {
    val response = requestJson("https://data-api.binance.vision/api/v3/ticker/bookTicker") as? JSONArray
        ?: throw IOException("Unexpected Binance response")
    val map = HashMap<String, Quote>(response.length())
    for (i in 0 until response.length()) {
        val item = response.optJSONObject(i) ?: continue
        val symbol = item.optString("symbol")
        if (!symbol.endsWith("USDT")) continue
        val bid = item.optString("bidPrice").toDoubleOrNull() ?: continue
        val ask = item.optString("askPrice").toDoubleOrNull() ?: continue
        val bidQty = item.optString("bidQty").toDoubleOrNull() ?: 0.0
        val askQty = item.optString("askQty").toDoubleOrNull() ?: 0.0
        if (bid > 0 && ask > 0) map[symbol] = Quote(symbol, bid, bidQty, ask, askQty)
    }
    if (map.isEmpty()) throw IOException("No USDT spot quotes returned")
    return map
}

private fun fetchBybitSpotQuotes(): Map<String, Quote> {
    val response = requestJson("https://api.bybit.com/v5/market/tickers?category=spot") as? JSONObject
        ?: throw IOException("Unexpected Bybit response")
    if (response.optInt("retCode", -1) != 0) throw IOException(response.optString("retMsg", "Bybit API error"))
    val list = response.optJSONObject("result")?.optJSONArray("list") ?: throw IOException("Missing ticker list")
    val map = HashMap<String, Quote>(list.length())
    for (i in 0 until list.length()) {
        val item = list.optJSONObject(i) ?: continue
        val symbol = item.optString("symbol")
        if (!symbol.endsWith("USDT")) continue
        val bid = item.optString("bid1Price").toDoubleOrNull() ?: continue
        val ask = item.optString("ask1Price").toDoubleOrNull() ?: continue
        val bidQty = item.optString("bid1Size").toDoubleOrNull() ?: 0.0
        val askQty = item.optString("ask1Size").toDoubleOrNull() ?: 0.0
        val turnover = item.optString("turnover24h").toDoubleOrNull() ?: 0.0
        if (bid > 0 && ask > 0) map[symbol] = Quote(symbol, bid, bidQty, ask, askQty, turnover)
    }
    if (map.isEmpty()) throw IOException("No USDT spot quotes returned")
    return map
}

private fun isPlainSpotAsset(base: String): Boolean {
    if (base.isBlank()) return false
    val banned = listOf("UP", "DOWN", "BULL", "BEAR", "3L", "3S", "5L", "5S")
    if (banned.any { base.endsWith(it) }) return false
    return base !in setOf("USDC", "FDUSD", "TUSD", "USDE", "DAI", "USDP", "BUSD")
}

private fun scanBinanceP2P(fiat: String, minimumNet: Double, reservePct: Double): P2PReport {
    if (!fiat.matches(Regex("[A-Z]{3,5}"))) {
        return P2PReport("Binance P2P", "Invalid fiat code", detail = "Enter a currency code such as TZS, USD or KES in Settings.")
    }
    return try {
        val buyAds = fetchBinanceP2PAds(fiat, "BUY")
        val sellAds = fetchBinanceP2PAds(fiat, "SELL")
        val buy = buyAds.minByOrNull { it.first }
        val sell = sellAds.maxByOrNull { it.first }
        if (buy == null || sell == null || buy.first <= 0) {
            P2PReport("Binance P2P", "No ads", detail = "The endpoint returned no usable offers for USDT/$fiat. The currency may not have active ads or the marketplace may block this request.")
        } else {
            val gross = (sell.first - buy.first) / buy.first * 100.0
            val net = gross - reservePct
            val detail = if (net >= minimumNet) {
                "Potentially clears your net threshold using best advertised prices. Confirm trade limits, payment method, and live offer availability in Binance before acting."
            } else {
                "Live ads were returned, but estimated net spread is below your ${pct(minimumNet)} alert floor. P2P reserve is a user-set allowance, not a guaranteed fee."
            }
            P2PReport("Binance P2P", "Live ads checked", buy.first, sell.first, net, buyAds.size, sellAds.size, detail, true)
        }
    } catch (e: Exception) {
        P2PReport("Binance P2P", "Unavailable", detail = "Could not load public P2P ads: ${safeMessage(e)}. No placeholder prices are shown.")
    }
}

private fun fetchBinanceP2PAds(fiat: String, tradeType: String): List<Pair<Double, Double>> {
    val body = JSONObject()
        .put("fiat", fiat)
        .put("page", 1)
        .put("rows", 20)
        .put("tradeType", tradeType)
        .put("asset", "USDT")
        .put("countries", JSONArray())
        .put("proMerchantAds", false)
        .put("shieldMerchantAds", false)
        .put("filterType", "all")
        .put("periods", JSONArray())
        .put("additionalKycVerifyFilter", 0)
        .put("publisherType", JSONObject.NULL)
        .put("payTypes", JSONArray())
    val response = requestJson(
        "https://p2p.binance.com/bapi/c2c/v2/friendly/c2c/adv/search",
        method = "POST",
        body = body.toString(),
        extraHeaders = mapOf("Origin" to "https://p2p.binance.com", "Referer" to "https://p2p.binance.com/")
    ) as? JSONObject ?: throw IOException("Unexpected Binance P2P response")
    val data = response.optJSONArray("data") ?: throw IOException(response.optString("message", "P2P response had no data"))
    val offers = ArrayList<Pair<Double, Double>>()
    for (i in 0 until data.length()) {
        val row = data.optJSONObject(i) ?: continue
        val adv = row.optJSONObject("adv") ?: continue
        val price = adv.optString("price").toDoubleOrNull() ?: continue
        val max = adv.optString("dynamicMaxSingleTransAmount").toDoubleOrNull()
            ?: adv.optString("maxSingleTransAmount").toDoubleOrNull() ?: 0.0
        if (price > 0.0) offers += price to max
    }
    return offers
}

private fun scanBybitP2P(bridge: String, bridgeToken: String, fiat: String, minimumNet: Double, reservePct: Double): P2PReport {
    if (bridge.isBlank()) {
        return P2PReport(
            platform = "Bybit P2P",
            status = "Setup required",
            detail = "Bybit's official P2P ads endpoint is restricted to eligible P2P advertisers. Configure a secure HTTPS bridge in Settings; API secrets must stay on that server."
        )
    }
    return try {
        val url = bridge.trimEnd('/') + "/p2p/bybit/quotes?asset=USDT&fiat=" + URLEncoder.encode(fiat, "UTF-8")
        val headers = if (bridgeToken.isNotBlank()) mapOf("X-ArbiScan-Token" to bridgeToken) else emptyMap()
        val response = requestJson(url, extraHeaders = headers) as? JSONObject ?: throw IOException("Unexpected bridge response")
        val buy = response.optString("buyPrice").toDoubleOrNull()
        val sell = response.optString("sellPrice").toDoubleOrNull()
        if (buy == null || sell == null || buy <= 0.0) throw IOException(response.optString("error", "Bridge response missing buyPrice/sellPrice"))
        val gross = (sell - buy) / buy * 100.0
        val net = gross - reservePct
        P2PReport(
            platform = "Bybit P2P", status = "Bridge connected", buyPrice = buy, sellPrice = sell,
            netPct = net, buyAds = response.optInt("buyAds", 0), sellAds = response.optInt("sellAds", 0),
            detail = if (net >= minimumNet) "Bridge quote clears your target. Check the live ad and trade limits on Bybit before proceeding."
            else "Quote is live through your configured bridge but below your ${pct(minimumNet)} alert threshold.",
            isLive = true
        )
    } catch (e: Exception) {
        P2PReport("Bybit P2P", "Bridge unavailable", detail = "Could not read the configured Bybit bridge: ${safeMessage(e)}")
    }
}

private fun requestJson(
    url: String,
    method: String = "GET",
    body: String? = null,
    extraHeaders: Map<String, String> = emptyMap()
): Any {
    val connection = (URL(url).openConnection() as HttpURLConnection).apply {
        requestMethod = method
        connectTimeout = 9_000
        readTimeout = 12_000
        useCaches = false
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "ArbiScanAndroid/0.1")
        if (body != null) {
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        }
        extraHeaders.forEach { (key, value) -> setRequestProperty(key, value) }
    }
    try {
        if (body != null) connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("HTTP $code${if (text.isNotBlank()) ": ${text.take(120)}" else ""}")
        val trimmed = text.trim()
        if (trimmed.startsWith("[")) return JSONArray(trimmed)
        if (trimmed.startsWith("{")) return JSONObject(trimmed)
        throw IOException("Server returned a non-JSON response")
    } finally {
        connection.disconnect()
    }
}

private fun maybeNotifyOpportunity(context: Context, prefs: android.content.SharedPreferences, opportunity: Opportunity?) {
    if (opportunity == null) return
    if (Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) return
    val key = "${opportunity.symbol}:${opportunity.buyExchange}:${opportunity.sellExchange}"
    val previous = prefs.getString("lastAlertKey", "")
    val previousTime = prefs.getLong("lastAlertTime", 0L)
    val now = System.currentTimeMillis()
    if (key == previous && now - previousTime < 30 * 60 * 1000L) return
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        android.app.Notification.Builder(context, CHANNEL_ID)
    } else {
        @Suppress("DEPRECATION")
        android.app.Notification.Builder(context)
    }
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentTitle("ArbiScan: ${pct(opportunity.netPct)} net estimate")
        .setContentText("${opportunity.symbol}: buy on ${opportunity.buyExchange}, sell on ${opportunity.sellExchange}. Verify live prices.")
        .setAutoCancel(true)
        .build()
    manager.notify(1101, notification)
    prefs.edit().putString("lastAlertKey", key).putLong("lastAlertTime", now).apply()
}

private fun openWeb(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun safeMessage(error: Throwable?): String {
    val text = error?.message?.replace('\n', ' ')?.trim().orEmpty()
    return if (text.isBlank()) "network/API error" else text.take(90)
}

private fun pct(value: Double): String = String.format(Locale.US, "%.2f%%", value)
private fun price(value: Double): String = when {
    value >= 1000.0 -> String.format(Locale.US, "$%,.2f", value)
    value >= 1.0 -> String.format(Locale.US, "$%.4f", value)
    else -> String.format(Locale.US, "$%.6f", value)
}
private fun money(value: Double): String = if (!value.isFinite() || value <= 0.0) "n/a" else String.format(Locale.US, "$%,.0f", value)
private fun moneyLocal(value: Double): String = String.format(Locale.US, "%,.2f", value)
